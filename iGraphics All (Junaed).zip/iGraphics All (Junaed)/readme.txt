Copy all the files from "Required Files" folder and paste them to
"C:\Program Files (x86)\Microsoft SDKs\Windows\v7.0A\Lib"

